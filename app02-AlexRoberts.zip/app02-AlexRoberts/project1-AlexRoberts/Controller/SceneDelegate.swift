//
//  SceneDelegate.swift
//  project1-AlexRoberts
//
//  Created by wsucatslabs on 9/14/23.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?



}

