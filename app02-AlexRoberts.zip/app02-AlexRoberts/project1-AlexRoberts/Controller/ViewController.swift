import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var setTextField : UITextField?
    @IBOutlet var keepEating : UILabel?
    @IBOutlet var fine : UILabel?      //fine
    @IBOutlet var sick : UILabel?      //sickness
    @IBOutlet var radWarning : UILabel! //radWarning
    @IBOutlet var calculation : UILabel? //rads
    @IBOutlet var background : UIView! //background color
    let model = logic()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // I just can't be bothered to figure out the return thing.
    //
    //func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    //    setTextField.resignFirstResponder()
    //return true
    //}
    
    @IBAction func submitSet() {
        var acceptedValue = Int(0)
        
        setTextField!.resignFirstResponder()
        
        if let enteredValue = Int(setTextField!.text!) {
            acceptedValue = enteredValue
        }
        
        let Rads = model.calculateBananaRads(bananas: acceptedValue)
        calculation!.text!=Rads
        
        fine!.isHidden = true
        radWarning!.isHidden = true
        sick!.isHidden = true
        keepEating!.isHidden = true
        calculation!.isHidden = true
        
        if(acceptedValue >= 10000000) { //Death
            background.backgroundColor = UIColor.red
            radWarning!.isHidden = false
            calculation!.isHidden = false
        }else if(acceptedValue >= 2000000 && acceptedValue < 10000000) { //Sickness
            background.backgroundColor = UIColor.yellow
            sick!.isHidden = false
            calculation!.isHidden = false
        }else if(acceptedValue >= 1000000 && acceptedValue < 2000000){ //Should be fine...
            background.backgroundColor = UIColor.green
            fine!.isHidden = false
            calculation!.isHidden = false
        }
        else if(acceptedValue < 1000000){ //Keep Eating
            background.backgroundColor = UIColor.green
            keepEating!.isHidden = false
            calculation!.isHidden = false
        }
    }
    
}
