import Foundation

//each banana is 0.1 microsieverts
//radiation sickness starts at 2 sieverts
//probably guaranteed to be fatal at 10 sieverts
//1 sievert is 1,000,000 microsieverts
class logic {
    func calculateBananaRads(bananas: Int) -> String {
        let radsPerBanana: Double = 0.1
        let totalRads = Double(bananas) * radsPerBanana
        return String(totalRads)+" μSv"
    }
}

